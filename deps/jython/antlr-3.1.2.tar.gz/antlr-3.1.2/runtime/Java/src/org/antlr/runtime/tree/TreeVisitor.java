package org.antlr.runtime.tree;

/** Do a depth first walk of a tree, applying pre() and post() actions
 *  we go.
 */
public class TreeVisitor {
    protected TreeAdaptor adaptor;
    
    public TreeVisitor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeVisitor() { this(new CommonTreeAdaptor()); }
    
    /** Visit every node in tree t and trigger an action for each node
     *  before/after having visited all of its children.  Bottom up walk.
     *  Execute both actions even if t has no children.  Ignore return
     *  results from transforming children since they will have altered
     *  the child list of this node (their parent).  Return result of
     *  applying post action to this node.
     */
    public Object visit(Object t, TreeVisitorAction action) {
        // System.out.println("visit "+((Tree)t).toStringTree());
        boolean isNil = adaptor.isNil(t);
        if ( action!=null && !isNil ) {
            t = action.pre(t); // if rewritten, walk children of new t
        }
        int n = adaptor.getChildCount(t);
        for (int i=0; i<n; i++) {
            Object child = adaptor.getChild(t, i);
            visit(child, action);
        }
        if ( action!=null && !isNil ) t = action.post(t);
        return t;
    }
}
